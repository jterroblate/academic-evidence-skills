# 按会议需求筛选的工具：先看这份

2026-10-13，JT为朋友准备，AI参与检索/静态源码核对。三条专题各核验6项候选，另下载接口/循环官方skill；本轮重点是找到真实部件与新增接入价值，未改正式v0.2.0、未连接账户/朋友工程、未调用收费后端。

## 最贴近会议的6组

| 名称 | 是什么 | 帮朋友做什么 | 现在采用的条件 |
| --- | --- | --- | --- |
| Zotero Local MCP Bridge（中文skill） | 真skill＋Zotero插件/MCP | 找条目/附件，创建有来源的文献项、挂人工补入PDF；覆盖1a、3e/3f中的Zotero动作 | 实际用本地用户库、需要写入且允许该插件；若现有Zotero运行时已能写，优先复用。AGPL-3.0-or-later，保留许可 |
| Obsidian CLI＋Markdown | 2个真实skill；执行依赖Obsidian CLI | Vault里的MD、属性、引用链接与PDF页嵌入；辅助1c归档 | 确认Vault由Obsidian使用；纯文件Vault只借Markdown规范。P编号仍由Registry给 |
| LangGraph human-in-the-loop＋persistence | 官方开发skill；另带fundamentals/primer参考 | 缺PDF时等待、保存任务和原query、人补料后恢复；对应3f与UI | 工程使用/选择LangGraph时接运行时；自建调度器可借状态设计，不强制换框架 |
| MCP Builder | 官方开发skill | 把2a/3a/3b的query、通道参数、所需字段、ID回取和错误设计成统一工具接口 | 需要开发接线；MCP为可选暴露方式，首版可用同合同本地函数 |
| Elicit官方API/MCP | 真官方外部服务/示例代码，示例小写skill.md非标准skill | 视频点名的外部科学搜索/报告；对应3c与Review候选材料 | 账户/额度和用途先对齐。API条款对独立索引/数据库聚合有明文限制，不能默认当EU采集器 |
| OpenAlex官方API/CLI | 官方外部入口与源码，无SKILL.md | 搜索文献元数据，按ID获取实际可用的PDF/TEI，供paper list候选与人工补库 | 沿用已配置渠道并限制用量；metadata-only成功不等于取得PDF；先单篇窄接入 |

真实入口与固定版本：

- [Zotero Bridge中文skill](https://github.com/PhoenixChenLu/zotero-local-mcp-bridge/blob/3e3f89019ad773ff756a3a6244324a8988dfdb93/skills/zotero-local-mcp-bridge-zh-cn/SKILL.md)
- [Obsidian CLI](https://github.com/kepano/obsidian-skills/blob/3ccff5338ea700537839b21900aa5358a0402c98/skills/obsidian-cli/SKILL.md)／[Markdown](https://github.com/kepano/obsidian-skills/blob/3ccff5338ea700537839b21900aa5358a0402c98/skills/obsidian-markdown/SKILL.md)
- [LangGraph官方skills](https://github.com/langchain-ai/langchain-skills/tree/16a992f09ab3ccfb642dd4f08d350d833d1990bf/config/skills)
- [MCP Builder](https://github.com/anthropics/skills/blob/dbd4588f9e1033efb41dad4bef2f7947c8993d44/skills/mcp-builder/SKILL.md)
- [Elicit官方接口](https://docs.elicit.com/)／[API条款](https://elicit.com/operations/api-terms)／[MIT样例源码](https://github.com/elicit/api-examples/tree/89e24c1b28510079aad24fcd73f8052858cc7257)
- [OpenAlex官方源码](https://github.com/ourresearch/openalex-official/tree/183ff7cd1997a67599a8095f8a7a672d2e5a37f8)／[认证与用量](https://help.openalex.org/api/authentication/)／[PDF/TEI接口](https://help.openalex.org/access/fulltext/)

## 视频另外两项怎么处理

**PDF→Markdown→quote+claim：** 继续复用已交付的pdf-to-markdown与academic-langextract。Google LangExtract本轮固定HEAD与已包版本相同，新增的是代码行为核验，不是再加一遍同技能。如果朋友原工程缺执行器，补一个保存原响应/跨度/失败的窄候选runner；现有编译接口已在则直接适配。字段扩展需要对齐真实schema，领域评价等派生信息分开，不能把SDK输出当FormalEU。

**semantic/lexical/graph统一召回＋指定字段回取：** 核验了Qdrant client的实际query/get接口，可在已选Qdrant时参考；先对接当前后端的一条search/get/span薄层。Pinecone官方FTS skill也真实并已下载，但仅现有Pinecone平台时考虑。LightRAG图是派生检索结构，部分data-only调用仍可能触发LLM抽关键词，后置。没有本轮候选能直接实现朋友EU ID、Registry和科学坐标协议。

## 给朋友怎么用

1. 先读本表，按自己当前Zotero/Vault/调度器渠道选一条路线。普通技能目录中的SKILL.md是使用/开发指引；依赖插件、CLI、SDK或商业服务要另配置。
2. 对纯skill，复制对应完整文件夹及许可到实际客户端的技能目录；实际目录按该客户端说明，不把整个候选资料目录当运行程序。运行源码快照不是构建发布包，安装插件/CLI须按固定上游仓库说明取得完整发行版。
3. Zotero入口先演示“按DOI/title找原条目和附件”，再用一篇经确认的人工PDF走已有链。缺项先记paper list待补；是否同时新建Zotero由原工程决定。不要用“附件存在”代替PDF书目身份核对。
4. LangGraph开发提示：保存task/原query/待补文献；缺PDF时暂停；人工补料后同一thread恢复；完成阶段写入幂等。内存checkpoint只证明当前进程，跨进程要持久化。
5. MCP Builder开发提示：将query、检索通道/参数、所需字段及ID精准回取定义为结构化合同；先一个后端；没有的通道明确disabled。不要让开发skill自行创造正式Source/EU ID。
6. Elicit账号和条款未对齐时，先用已有的OpenAlex/Crossref等渠道验证已有/缺文献两分支，保存原返回。两个外部入口输出先作候选，摘要/商业报告不替代原文。

首轮研究端仍是“人给题目→Review完整综述”，本次部件支撑它的材料与调用循环。原创突破是后续研究目标，不是下载安装成功的验收。

## 交付和仍需适配的部分

候选下载收录真实skill、许可和固定源码参照；这是**候选资料**，不是更新后的正式完整技能包。正式最新版仍为16项v0.2.0。运行依赖、真实库/模型、统一EU写口、paper list/UI、identity与正式schema都没有代测。被排除/后置的工具及源码问题保留在专题报告中，方便选型时回看。

完整防幻觉增强后置不等于移除已有机制。候选保留来源与状态；按块重跑仍须区分失败与远端未知，避免重复外呼/建项。
