# 外部入口源码参考

Elicit为会议具体提及的候选，官方有REST/MCP；仓库小写skill.md缺标准YAML，不能当已可发现的Codex skill。源码MIT与服务使用资格/条款分别判断。接口与条款：https://docs.elicit.com/ 、https://elicit.com/operations/api-terms 。在账户与用途对齐之前，不默认调用/建报告或将输出建独立索引。

OpenAlex官方CLI/API无SKILL.md。可借query/指定ID metadata及available PDF/TEI回取；真实PDF与解析TEI分别保存。API额度/key/内容许可按当前官方说明，原例大批量并发、metadata-only success和overwrite不可默认照搬最小循环。

归档固定commit与SHA在来源与边界.json。保留MIT。这里是源码参考，没有解包安装或运行，不包含任何账户key、论文数据库或朋友私有资料。
